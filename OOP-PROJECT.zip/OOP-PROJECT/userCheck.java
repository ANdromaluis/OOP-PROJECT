public class userCheck{
    public void checkSampleBookings() {
        Building sitBuilding = new SITBuilding("SIT", "School of Information Technology");
        sitBuilding.addRoom(new StudyRoom("SIT-4/1", 4, 70, 6.0, 8.0, 3.0, true));

        Building lxBuilding = new LXBuilding("LX", "LX Building");
        lxBuilding.addRoom(new StudyRoom("LX-10/1", 10, 20, 6.0, 8.0, 3.5, false));
        lxBuilding.addRoom(new StudyRoom("LX-10/2", 10, 20, 6.0, 8.0, 3.5, true));
        lxBuilding.addRoom(new labRoom("LX-10/3", 10, 30, 8.0, 10.0, 3.5, 20));
        lxBuilding.addRoom(new labRoom("LX-10/4", 10, 30, 8.0, 10.0, 3.5, 20));
        lxBuilding.addRoom(new StudyRoom("LX-10/5", 10, 30, 10.0, 12.0, 3.5, true));

        User[] users = {
                new Student("Aya", "Computer Science", "aya@example.edu", "65010001"),
                new Student("Mark", "Information Technology", "mark@example.edu", "65010002"),
                new Professor("Dr. Somchai", "Computer Science", "somchai@example.edu")
        };

        Building[] buildings = { lxBuilding, lxBuilding, sitBuilding };
        String[] roomIds = { "LX-10/4", "LX-10/4", "SIT-4/1" };
        int[][] bookingTimes = { { 9, 11 }, { 11, 13 }, { 9, 12 } };

        for (int i = 0; i < users.length; i++) {
            abstractRoom room = buildings[i].getEmptyRoom(roomIds[i]);
            if (room != null && room.book(bookingTimes[i][0], bookingTimes[i][1])) {
                System.out.println(users[i] + " reserved room " + room.getRoomID() + " from "
                        + bookingTimes[i][0] + ":00" + "-" + bookingTimes[i][1] + ":00");
            } else {
                System.out.println("Could not reserve room " + roomIds[i]
                        + " for " + users[i].getName());
            }
        }
    }
}